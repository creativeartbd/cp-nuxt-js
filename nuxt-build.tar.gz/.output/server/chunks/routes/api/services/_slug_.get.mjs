import { d as defineCachedEventHandler, u as useRuntimeConfig, c as createError } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const _slug__get = defineCachedEventHandler(
  async (event) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    const { slug } = event.context.params;
    const config = useRuntimeConfig();
    try {
      try {
        return await $fetch(`/cutout/v1/service/${slug}`, {
          baseURL: config.public.wordpressApiUrl
        });
      } catch (customError) {
        console.log(`Custom service endpoint not found for ${slug}, trying WP REST API...`);
        let response;
        try {
          response = await $fetch(`/wp/v2/service?slug=${slug}&_embed=true`, {
            baseURL: config.public.wordpressApiUrl
          });
        } catch (e) {
          response = await $fetch(`/wp/v2/services?slug=${slug}&_embed=true`, {
            baseURL: config.public.wordpressApiUrl
          });
        }
        if (!response || !Array.isArray(response) || response.length === 0) {
          throw createError({
            statusCode: 404,
            message: `Service not found: ${slug}`
          });
        }
        const service = response[0];
        return {
          page: {
            id: service.id,
            title: ((_a = service.title) == null ? void 0 : _a.rendered) || ""
          },
          sections: ((_b = service.acf) == null ? void 0 : _b.sections) || [],
          seo: {
            title: ((_c = service.yoast_head_json) == null ? void 0 : _c.title) || ((_d = service.title) == null ? void 0 : _d.rendered),
            description: ((_e = service.yoast_head_json) == null ? void 0 : _e.description) || "",
            og_title: (_f = service.yoast_head_json) == null ? void 0 : _f.og_title,
            og_description: (_g = service.yoast_head_json) == null ? void 0 : _g.og_description,
            og_image: (_j = (_i = (_h = service.yoast_head_json) == null ? void 0 : _h.og_image) == null ? void 0 : _i[0]) == null ? void 0 : _j.url
          }
        };
      }
    } catch (error) {
      console.error(`Error fetching service ${slug}:`, error);
      throw createError({
        statusCode: 404,
        message: `Service not found: ${slug}`
      });
    }
  },
  {
    maxAge: 60 * 10,
    // 10 minutes
    name: "service"
  }
);

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
