import { a as defineEventHandler, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const siteSettings_get = defineEventHandler(
  async () => {
    const config = useRuntimeConfig();
    try {
      const data = await $fetch(`${config.public.wordpressApiUrl}/cutout/v1/settings`);
      console.log("\u2705 Site settings loaded from custom endpoint");
      return data;
    } catch (error) {
      console.warn("\u26A0\uFE0F Custom endpoint failed, trying fallback...");
      try {
        const data = await $fetch(`${config.public.wordpressApiUrl}/wp/v2/theme-options`);
        return {
          site_name: "Cutout Partner",
          all_fields: data || {}
        };
      } catch (fallbackError) {
        console.error("\u274C All site settings endpoints failed");
        return {
          site_name: "Cutout Partner",
          site_description: "Professional Photo Editing Services",
          site_url: config.public.siteUrl,
          all_fields: {
            site_logo: "",
            home_logo: "",
            sticky_logo: "",
            other_pages_logo: "",
            footer_section: [],
            select_services: []
          }
        };
      }
    }
  });

export { siteSettings_get as default };
//# sourceMappingURL=site-settings.get.mjs.map
