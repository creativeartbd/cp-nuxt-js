import { d as defineCachedEventHandler, u as useRuntimeConfig, g as getQuery } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_get = defineCachedEventHandler(
  async (event) => {
    const config = useRuntimeConfig();
    const query = getQuery(event);
    const page = query.page || "1";
    const perPage = query.per_page || "10";
    try {
      return await $fetch(`/cutout/v1/posts?page=${page}&per_page=${perPage}`, {
        baseURL: config.public.wordpressApiUrl
      });
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      return { posts: [], total: 0 };
    }
  },
  {
    maxAge: 60 * 10,
    // 10 minutes
    name: "blog-list"
  }
);

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
