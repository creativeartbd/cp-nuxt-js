import { d as defineCachedEventHandler, g as getQuery, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const menu_get = defineCachedEventHandler(
  async (event) => {
    const query = getQuery(event);
    const slug = query.slug || "primary";
    const config = useRuntimeConfig();
    try {
      try {
        return await $fetch(`${config.public.wordpressApiUrl}/cutout/v1/menu/${slug}`);
      } catch (customError) {
        console.log("Custom menu endpoint not found, trying WP REST API menus...");
        try {
          const menus = await $fetch(`${config.public.wordpressApiUrl}/wp-api-menus/v2/menus`);
          const menu = Array.isArray(menus) ? menus.find((m) => m.slug === slug) : null;
          return (menu == null ? void 0 : menu.items) || [];
        } catch (wpMenuError) {
          console.warn("No menu API available, returning empty menu");
          return [];
        }
      }
    } catch (error) {
      console.error("Error fetching menu:", error);
      return [];
    }
  },
  {
    maxAge: 60 * 15,
    // 15 minutes
    name: "menu"
  }
);

export { menu_get as default };
//# sourceMappingURL=menu.get.mjs.map
