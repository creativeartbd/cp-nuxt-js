import { d as defineCachedEventHandler, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const _slug__get = defineCachedEventHandler(
  async (event) => {
    const { slug } = event.context.params;
    const config = useRuntimeConfig();
    const res = await $fetch(`${config.wpBaseUrl}/pages/${slug}`);
    return res;
  },
  {
    maxAge: 60 * 10,
    name: "page"
  }
);

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
