import { d as defineCachedEventHandler, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_get = defineCachedEventHandler(
  async () => {
    const config = useRuntimeConfig();
    try {
      return await $fetch(`/cutout/v1/services`, {
        baseURL: config.public.wordpressApiUrl
      });
    } catch (error) {
      console.error("Error fetching services list:", error);
      return [];
    }
  },
  {
    maxAge: 60 * 10,
    // 10 minutes
    name: "services-list"
  }
);

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
