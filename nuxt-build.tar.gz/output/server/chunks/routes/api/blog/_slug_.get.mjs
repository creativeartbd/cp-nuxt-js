import { d as defineCachedEventHandler, u as useRuntimeConfig, c as createError } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const _slug__get = defineCachedEventHandler(
  async (event) => {
    const { slug } = event.context.params;
    const config = useRuntimeConfig();
    try {
      return await $fetch(`/cutout/v1/post/${slug}`, {
        baseURL: config.public.wordpressApiUrl
      });
    } catch (error) {
      console.error(`Error fetching blog post ${slug}:`, error);
      throw createError({
        statusCode: 404,
        message: `Blog post not found: ${slug}`
      });
    }
  },
  {
    maxAge: 60 * 10,
    // 10 minutes
    name: "blog-post"
  }
);

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
